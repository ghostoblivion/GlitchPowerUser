async function displayModal() {
    const modal = await document.createElement("dialog");
    // Create a dialog element
    modal.style =
        "background-color: var(--variable-shim-primary-background);font-size: 14px;margin: 0;cursor: initial;display: block;position: absolute;top: 24px;left: 350px;border-radius: 3px;border: 1px solid var(--variable-shim-secondary);box-shadow: var(--variable-shim-pop-shadow);z-index: 1000;width: 600px;padding: 0;-webkit-overflow-scrolling: touch;overflow-y: auto;max-height: calc(88vh - 45px);";
    // Give it some design
    await modal.setAttribute("id", "gdModal");
    // Give it an ID
    const section = await document.createElement("section");
    // Create a section
    await section.classList.add("actions");
    // Give it a Glitch class
    section.style += "padding: 20px !important; margin: 20px !important";
    // And a few additional styles
    const buttons = await document.createElement("div");
    // Create a button container
    await buttons.classList.add("button-wrap");
    // Give it a Glitch class
    const button = await document.createElement("button");
    // Create a button
    button.style =
        "background-color: var(--variable-shim-primary-background);color: #fff;border-radius: 5px;border: 2px solid #999;padding-top: 4px;padding-bottom: 3px;margin-bottom: 6px;margin-top: 3px;padding-right: 7px;padding-left: 7px;";
    // Give it some style
    button.textContent = "Close";
    // And some text
    await button.addEventListener("click", closeModal);
    // And an event listener
    await buttons.appendChild(button);
    // Add the button to the button container
    const desc = await document.createElement("h4");
    // Make a description
    desc.textContent = "Select a Theme";
    // With text
    desc.style = "font-size: 14px;color: #eee;";
    // And style

    const themeSelector = await document.createElement("select");
    // Create a dropdown
    await themeSelector.addEventListener("change", selectTheme);
    // Add an event listener
    await themeSelector.setAttribute("id", "themeSelector");
    // Give it an ID
    themeSelector.style =
        "background-color: var(--variable-shim-primary-background);color: #fff;border-radius: 5px;border: 2px solid #999;padding-top: 4px;padding-bottom: 3px;margin-bottom: 6px;margin-top: 3px;padding-right: 3px;padding-left: 4px;";
    // Give it some style
    await window.___themes.forEach(async theme => {
        // Quick forEach loop
        var xhr = new XMLHttpRequest();
        // Create a XMLHTTP request
        xhr.onreadystatechange = async function() {
            // Listen for request state changes
            if (xhr.readyState === 4) {
                var option = await document.createElement("option");
                // Create an option
                option.id = await JSON.parse(xhr.responseText)
                    .theme;
                // Give it an ID
                option.text = await JSON.parse(xhr.responseText)
                    .theme;
                // And some text
                option.style =
                    "background-color: var(--variable-shim-primary-background);color: #fff;border: 2px solid #999;padding-top: 2px;padding-bottom: 1px;";
                // And style...
                await themeSelector.add(option);
                // Add it to the dropdown
            }
        };
        await xhr.open(
            "GET",
            chrome.extension.getURL(`/themes/${theme}.json`),
            true
        );
        // Open the request
        await xhr.send();
        // Send the request
    });
    setTimeout(async () => {
        if (await JSON.parse(window.localStorage.getItem("gdStyle"))) {
            // Check if there's style set
            const z = await JSON.parse(window.localStorage.getItem("gdStyle"));
            // If it is...
            themeSelector.value = z.theme;
            // Make it the default option
        }
    }, 5000);
    section.appendChild(desc);
    // Add the description
    section.appendChild(themeSelector);
    // Add the dropdown
    section.appendChild(buttons);
    // Add the buttons
    modal.appendChild(section);
    // Add the section
    document.getElementById("application")
        .appendChild(modal);
    // Inject it
}

function closeModal() {
    document.getElementById("gdModal")
        .remove();
    // Remove the modal
}

window.onload = async function() {
    window.___themes = [];
    // Init a new array for theme data.
    chrome.runtime.getManifest()
        .web_accessible_resources.forEach(async theme => {
            // A forEach loop to get the data from the manifest file
            await window.___themes.push(
                theme.replace("themes/", "")
                .replace(".json", "")
            );
            // Push the theme into the window.___themes array
        });

    const body = document.body;
    // Get the document

    const gdstyle = await document.createElement("style");
    // Create the gdStyle inject
    gdstyle.setAttribute("id", "gdStyle");
    // Give it an ID so we can safely get it later
    const CodeMirrorStyleDefaults = await document.createElement("style");
    // Set CodeMirror to the default design so all the themes work properly
    CodeMirrorStyleDefaults.setAttribute("id", "CodeMirrorStyleDefaults");
    // Give it an ID in case we need it later
    CodeMirrorStyleDefaults.innerHTML =
        ".CodeMirror-linenumber{padding:0 3px 0 5px!important;min-width:20px!important;text-align:right!important;white-space:nowrap!important;font-size:13px!important}.CodeMirror-linenumber{-moz-box-sizing:content-box!important;box-sizing:content-box!important}.theme-cosmos,.theme-sugar{--variable-shim-matching-bracket-highlight:transparent !important;}";
    // The default
    body.appendChild(CodeMirrorStyleDefaults);
    // Inject it
    if (!(await JSON.parse(window.localStorage.getItem("gdStyle")))) {
        // Check for the gdStyle cookie
        var xhr = new XMLHttpRequest();
        // Create a XMLHTTP request
        xhr.onreadystatechange = async function() {
            // Listen for request state changes
            if (xhr.readyState === 4) {
                gdstyle.innerHTML = JSON.parse(xhr.responseText)
                    .codemirror;
                // Set the theme to dracula since no setting was found
                body.appendChild(gdstyle);
                // Inject it
            }
        };
        xhr.open("GET", chrome.extension.getURL(`/themes/dracula.json`), true);
        // Open the request
        xhr.send();
        // Send the request
    } else {
        const style = await JSON.parse(window.localStorage.getItem("gdStyle"));
        // Get the style
        if (window.___themes.includes(style.theme)) {
            // Check if the theme exists
            var xhr = new XMLHttpRequest();
            // Create a XMLHTTP request
            xhr.onreadystatechange = async function() {
                // Listen for request state changes
                if (xhr.readyState === 4) {
                    gdstyle.innerHTML = await JSON.parse(xhr.responseText)
                        .codemirror;
                    // Set the theme to the users requested theme
                    body.appendChild(gdstyle);
                    // Inject it
                }
            };
            xhr.open(
                "GET",
                chrome.extension.getURL(`/themes/${style.theme}.json`),
                true
            );
            // Open the request
            xhr.send();
            // Send the request
        } else {
            alert(
                "Uh, looks like that theme doesn't exist!  Please set a new theme."
            );
            // Display an error if the theme isn't found
        }
    }

    const before = document.getElementById("header-project");
    // Get the header
    const container = document.createElement("div");
    // Create a new container
    const settings = document.createElement("button");
    // Add a button
    container.classList.add("show-app-wrapper");
    // Add some design lol
    settings.textContent = "Editor Theme";
    // Add some text
    settings.addEventListener("click", displayModal);
    // Add an event listener in case the other doesn't work
    const a = "show-app icon nav-item no-button-styles opens-pop-over".split(" ");
    // Quick way to make an array of the styles we want to add
    for (i in a) {
        settings.classList.add(a[i]);
        // A quick for loop to apply all the above styles
    }
    container.appendChild(settings);
    // Add the button to the container
    before.insertAdjacentElement("afterend", container);
    // Inject the container
};

async function selectTheme() {
    var theme = await document.getElementById("themeSelector")
        .value;
    // Get the new theme
    if (!window.___themes.includes(theme)) {
        alert("Uh, looks like that theme doesn't exist!  Please set a new theme.");
        // Display an error if the theme isn't found
    } else {
        await window.localStorage.setItem(
            "gdStyle",
            JSON.stringify({
                theme: theme
            })
        );
        var xhr = new XMLHttpRequest();
        // Create a XMLHTTP request
        xhr.onreadystatechange = async function() {
            // Listen for request state changes
            if (xhr.readyState === 4) {
                document.getElementById("gdStyle")
                    .innerHTML = await JSON.parse(
                        xhr.responseText
                    )
                    .codemirror;
                // Set the theme to the users requested theme
            }
        };
        xhr.open("GET", chrome.extension.getURL(`/themes/${theme}.json`), true);
        // Open the request
        xhr.send();
        // Send the request
    }
}
async function selectEditorSetting() {}
